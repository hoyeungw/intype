## intype
##### dynamic infer type

### Usage
```python
from intype import has_literal
word = 'chocolate'
print(has_literal(word))
```