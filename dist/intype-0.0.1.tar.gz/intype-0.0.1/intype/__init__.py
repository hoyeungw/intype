__version__ = '0.0.1'

from .literal import has_literal, is_literal, is_string
from .numeric import is_numeric
